import 'package:flutter/material.dart';

class tvprogramme {
  final String tvprogramme_name;
  final String Image;
  final Color color;

  tvprogramme(this.tvprogramme_name, this.Image, this.color);
}

class programme_details {
  final String group;
  final String time;
  final String score1;
  final String score2;
  final String team1;
  final String team2;
  final String Date;

  programme_details(this.group, this.time, this.score1, this.score2, this.team1, this.team2, this.Date);
}