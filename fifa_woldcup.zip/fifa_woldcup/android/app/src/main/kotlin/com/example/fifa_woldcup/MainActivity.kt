package com.example.fifa_woldcup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
